var map;
console.log("Loading Map...")

function initMap() {
	navigator.geolocation.getCurrentPosition(function (position) {
		console.log(position.coords.latitude, position.coords.longitude);
		map = new google.maps.Map(document.getElementById('map'), {
			center: {
				lat: position.coords.latitude,
				lng: position.coords.longitude
			},
			zoom: 12
		});
		fetch('https://www.hikingproject.com/data/get-trails?lat=49.267941&lon=-123.247360&key=200374350-e954741ee27b3d305a1cb6138f1aebfd')
			.then(
				function (response) {
					if (response.status !== 200) {
						console.log('Looks like there was a problem. Status Code: ' +
							response.status);
						return;
					}

					// Examine the text in the response
					response.json().then(function (data) {
						console.log(data);
						var firstTrail = data.trails[0];
						console.log(firstTrail);
						document.getElementById('row-image-1').src=firstTrail.imgMedium;
						document.getElementById('row-image-1').style.height='auto';
						document.getElementById('row-image-1').style.width='100vh';
						document.getElementById('row-title-1').textContent=firstTrail.name;
						document.getElementById('row-description-1').textContent=firstTrail.summary;
					});
				}
			)
			.catch(function (err) {
				console.log('Fetch Error :-S', err);
			});
	});
}
